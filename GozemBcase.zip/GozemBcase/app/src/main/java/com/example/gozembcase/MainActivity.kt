package com.example.gozembcase

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.gozembcase.databinding.ActivityMainBinding
import com.example.gozembcase.databinding.LogincardviewBinding

class MainActivity : AppCompatActivity() {

    private lateinit var emailFragment: Fragment
    private lateinit var activity: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activity= ActivityMainBinding.inflate(layoutInflater)
        setContentView(activity.root)


     //emailFragment= EmailFragment()
        supportFragmentManager.beginTransaction().add(R.id.fragmentContainerView, EmailFragment()).addToBackStack(null).commit()
    }





}